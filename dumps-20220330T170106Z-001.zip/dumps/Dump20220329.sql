-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcountry`
--

DROP TABLE IF EXISTS `tblcountry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcountry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `txtCountryName` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcountry`
--

LOCK TABLES `tblcountry` WRITE;
/*!40000 ALTER TABLE `tblcountry` DISABLE KEYS */;
INSERT INTO `tblcountry` VALUES (1,'India'),(2,'America'),(3,'China'),(4,'Srilanka'),(5,'England');
/*!40000 ALTER TABLE `tblcountry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblorderchild`
--

DROP TABLE IF EXISTS `tblorderchild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblorderchild` (
  `id` int NOT NULL AUTO_INCREMENT,
  `refOrderHdr` int NOT NULL,
  `refProduct` int NOT NULL,
  `txtQuantity` varchar(50) NOT NULL,
  `txtTotalAmount` varchar(50) NOT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refOrderHdr` (`refOrderHdr`),
  KEY `refProduct` (`refProduct`),
  CONSTRAINT `tblorderchild_ibfk_1` FOREIGN KEY (`refOrderHdr`) REFERENCES `tblorderhdr` (`id`),
  CONSTRAINT `tblorderchild_ibfk_2` FOREIGN KEY (`refProduct`) REFERENCES `tblproduct` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblorderchild`
--

LOCK TABLES `tblorderchild` WRITE;
/*!40000 ALTER TABLE `tblorderchild` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblorderchild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblorderhdr`
--

DROP TABLE IF EXISTS `tblorderhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblorderhdr` (
  `id` int NOT NULL AUTO_INCREMENT,
  `refUser` int NOT NULL,
  `txtOrderNo` varchar(50) NOT NULL,
  `txtOrderAmount` varchar(50) NOT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refUser` (`refUser`),
  CONSTRAINT `tblorderhdr_ibfk_1` FOREIGN KEY (`refUser`) REFERENCES `tblusers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblorderhdr`
--

LOCK TABLES `tblorderhdr` WRITE;
/*!40000 ALTER TABLE `tblorderhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblorderhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproduct`
--

DROP TABLE IF EXISTS `tblproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproduct` (
  `id` int NOT NULL AUTO_INCREMENT,
  `txtProdName` varchar(50) NOT NULL,
  `txtProdPrice` varchar(50) NOT NULL,
  `refProdCategory` int NOT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refProdCategory` (`refProdCategory`),
  CONSTRAINT `tblproduct_ibfk_1` FOREIGN KEY (`refProdCategory`) REFERENCES `tblproductcategory` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproduct`
--

LOCK TABLES `tblproduct` WRITE;
/*!40000 ALTER TABLE `tblproduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblproductcategory`
--

DROP TABLE IF EXISTS `tblproductcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblproductcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `txtCategoryName` varchar(50) NOT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblproductcategory`
--

LOCK TABLES `tblproductcategory` WRITE;
/*!40000 ALTER TABLE `tblproductcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblproductcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblstate`
--

DROP TABLE IF EXISTS `tblstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblstate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `txtStateName` varchar(50) NOT NULL,
  `refCountryName` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refCountryName` (`refCountryName`),
  CONSTRAINT `tblstate_ibfk_1` FOREIGN KEY (`refCountryName`) REFERENCES `tblcountry` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblstate`
--

LOCK TABLES `tblstate` WRITE;
/*!40000 ALTER TABLE `tblstate` DISABLE KEYS */;
INSERT INTO `tblstate` VALUES (1,'kerala',1),(2,'tamil nadu',1),(3,'karnataka',1),(4,'washington',2),(5,'new york',2),(6,'hainan',3),(7,'colombo',4),(8,'london',5);
/*!40000 ALTER TABLE `tblstate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblusers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `refUserType` int NOT NULL,
  `txtUsername` varchar(50) NOT NULL,
  `txtPassword` varchar(50) NOT NULL,
  `txtFirstname` varchar(50) DEFAULT NULL,
  `txtLastname` varchar(50) DEFAULT NULL,
  `refCountry` int DEFAULT NULL,
  `refState` int DEFAULT NULL,
  `txtAddress` varchar(50) DEFAULT NULL,
  `txtStreet` varchar(50) DEFAULT NULL,
  `txtCity` varchar(50) DEFAULT NULL,
  `txtPincode` varchar(50) DEFAULT NULL,
  `txtPhoneNo` varchar(50) DEFAULT NULL,
  `txtWebsite` varchar(50) DEFAULT NULL,
  `bISRegistered` tinyint(1) DEFAULT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `txtUsername_UNIQUE` (`txtUsername`),
  KEY `refUserType` (`refUserType`),
  KEY `tblusers_ibfk_1` (`refCountry`),
  KEY `tblusers_ibfk_2` (`refState`),
  CONSTRAINT `tblusers_ibfk_1` FOREIGN KEY (`refCountry`) REFERENCES `tblcountry` (`id`),
  CONSTRAINT `tblusers_ibfk_2` FOREIGN KEY (`refState`) REFERENCES `tblstate` (`id`),
  CONSTRAINT `tblusers_ibfk_3` FOREIGN KEY (`refUserType`) REFERENCES `tblusertype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` VALUES (2,3,'karthi123','123','karthik','k',1,2,'abc','mint','chennai','600003','9102159744','karthik.com',0,'2022-02-15 12:51:19','2022-03-10 08:45:16',0),(3,4,'john123','123','john','adams',2,4,'abc','10th avenue','jacksonville','32034','1237584401','johnadams.com',1,'2022-01-04 07:32:58','2022-02-02 09:17:36',0),(7,1,'yungzu','123','yung','zu',3,6,'bbmbn','qilou old street','haikou','570000','8600005210','yungzu.com',1,'2020-08-18 02:55:25','2022-03-10 08:45:16',1),(8,1,'lash1123','123','lashith','perera',4,7,'ghfy','10th line','colombo','00130','9452789632','lash.com',0,'2019-11-09 23:27:15','2020-05-03 17:54:59',0),(12,2,'karthi','123','karthik','KR',1,2,'def','mint','chennai','600003','910215974476','fun4u.com',1,'2022-02-15 12:51:19','2022-03-10 08:45:16',0),(13,2,'John','123','John','Martines',1,5,'hij','10th avenue','jacksonville','32034','12375844010','johnmartines.com',0,'2022-01-04 07:32:58','2022-02-02 09:17:36',1),(45,1,'abhi123','123','Abin','Issac',1,1,'abc','dpd','ekm','683562','4467863737','abintalks.com',1,'2022-03-21 10:30:09','2022-03-23 11:10:09',0),(70,1,'abhi','123','Abin','Issac',1,1,'abc','dpd','ekm','683562','910011277222','abintalks.com',1,'2022-03-21 10:30:09','2022-03-23 11:10:09',0);
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblusertype`
--

DROP TABLE IF EXISTS `tblusertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblusertype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `txtUserType` varchar(50) NOT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusertype`
--

LOCK TABLES `tblusertype` WRITE;
/*!40000 ALTER TABLE `tblusertype` DISABLE KEYS */;
INSERT INTO `tblusertype` VALUES (1,'store','2022-03-21 10:30:09','2022-03-23 11:10:45',1),(2,'customer','2022-02-05 21:12:47','2022-03-20 10:10:13',0),(3,'customer','2021-07-08 18:30:12','2022-01-30 05:40:55',1),(4,'store','2020-12-11 14:23:17','2021-07-07 16:17:35',0);
/*!40000 ALTER TABLE `tblusertype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-29 23:02:11
