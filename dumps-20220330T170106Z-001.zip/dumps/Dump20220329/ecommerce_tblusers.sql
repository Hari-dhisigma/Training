-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblusers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `refUserType` int NOT NULL,
  `txtUsername` varchar(50) NOT NULL,
  `txtPassword` varchar(50) NOT NULL,
  `txtFirstname` varchar(50) DEFAULT NULL,
  `txtLastname` varchar(50) DEFAULT NULL,
  `refCountry` int DEFAULT NULL,
  `refState` int DEFAULT NULL,
  `txtAddress` varchar(50) DEFAULT NULL,
  `txtStreet` varchar(50) DEFAULT NULL,
  `txtCity` varchar(50) DEFAULT NULL,
  `txtPincode` varchar(50) DEFAULT NULL,
  `txtPhoneNo` varchar(50) DEFAULT NULL,
  `txtWebsite` varchar(50) DEFAULT NULL,
  `bISRegistered` tinyint(1) DEFAULT NULL,
  `dtCreatedOn` datetime DEFAULT NULL,
  `dtUpdatedOn` datetime DEFAULT NULL,
  `bDeleteFlag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `txtUsername_UNIQUE` (`txtUsername`),
  KEY `refUserType` (`refUserType`),
  KEY `tblusers_ibfk_1` (`refCountry`),
  KEY `tblusers_ibfk_2` (`refState`),
  CONSTRAINT `tblusers_ibfk_1` FOREIGN KEY (`refCountry`) REFERENCES `tblcountry` (`id`),
  CONSTRAINT `tblusers_ibfk_2` FOREIGN KEY (`refState`) REFERENCES `tblstate` (`id`),
  CONSTRAINT `tblusers_ibfk_3` FOREIGN KEY (`refUserType`) REFERENCES `tblusertype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` VALUES (2,3,'karthi123','123','karthik','k',1,2,'abc','mint','chennai','600003','9102159744','karthik.com',0,'2022-02-15 12:51:19','2022-03-10 08:45:16',0),(3,4,'john123','123','john','adams',2,4,'abc','10th avenue','jacksonville','32034','1237584401','johnadams.com',1,'2022-01-04 07:32:58','2022-02-02 09:17:36',0),(7,1,'yungzu','123','yung','zu',3,6,'bbmbn','qilou old street','haikou','570000','8600005210','yungzu.com',1,'2020-08-18 02:55:25','2022-03-10 08:45:16',1),(8,1,'lash1123','123','lashith','perera',4,7,'ghfy','10th line','colombo','00130','9452789632','lash.com',0,'2019-11-09 23:27:15','2020-05-03 17:54:59',0),(12,2,'karthi','123','karthik','KR',1,2,'def','mint','chennai','600003','910215974476','fun4u.com',1,'2022-02-15 12:51:19','2022-03-10 08:45:16',0),(13,2,'John','123','John','Martines',1,5,'hij','10th avenue','jacksonville','32034','12375844010','johnmartines.com',0,'2022-01-04 07:32:58','2022-02-02 09:17:36',1),(45,1,'abhi123','123','Abin','Issac',1,1,'abc','dpd','ekm','683562','4467863737','abintalks.com',1,'2022-03-21 10:30:09','2022-03-23 11:10:09',0),(70,1,'abhi','123','Abin','Issac',1,1,'abc','dpd','ekm','683562','910011277222','abintalks.com',1,'2022-03-21 10:30:09','2022-03-23 11:10:09',0);
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-29 23:00:41
