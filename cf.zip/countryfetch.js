

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "ecommerce.c56ayiprrn3s.us-west-2.rds.amazonaws.com",
  user: "admin",
  password: "12345678",
  database: "ecommerce"
});

con.connect(function (err) {
  if (err) throw err;
  console.log("Connected!");
});


//Signup API for country fetch
exports.handler = (event, context) => {
  con.query("SELECT id,txtCountryname FROM tblCountry;", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    // res.send(result);
    context.succeed('Success');
    
  });
};


